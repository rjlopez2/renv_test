library(testthat)
library(AnlysisOfWaves)

test_check("AnlysisOfWaves")
